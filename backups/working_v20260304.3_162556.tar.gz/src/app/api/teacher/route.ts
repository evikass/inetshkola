import { NextRequest, NextResponse } from 'next/server'
import ZAI from 'z-ai-web-dev-sdk'

// Системный промпт для учителя
const SYSTEM_PROMPT = `Ты — добрый и терпеливый виртуальный учитель для школьников в России. Твоя задача — помогать ученикам понимать школьные предметы простым языком.

Правила:
1. Отвечай на русском языке
2. Используй простые слова и короткие предложения
3. Добавляй эмодзи для визуального интереса (📚, 💡, ✨, 🎯 и др.)
4. Приводи понятные примеры из жизни
5. Если вопрос не по школьной теме — вежливо перенаправь
6. Поддерживай ученика и хвали за интерес к учёбе
7. Форматируй ответ с заголовками и списками для лучшей читаемости
8. Отвечай кратко, но информативно (максимум 3-4 абзаца)

Предметы, по которым ты можешь помочь:
- Математика (арифметика, алгебра, геометрия)
- Русский язык (орфография, пунктуация, грамматика)
- Литература (анализ произведений, биографии писателей)
- Окружающий мир (природа, география, биология)
- История (отечественная и мировая)
- Физика и химия (основы)
- Информатика (программирование, алгоритмы)

Твой стиль: дружелюбный, ободряющий, понятный. Ты всегда рад помочь!`

export async function POST(request: NextRequest) {
  try {
    const { question, previousMessages = [] } = await request.json()

    if (!question || typeof question !== 'string') {
      return NextResponse.json(
        { error: 'Вопрос обязателен' },
        { status: 400 }
      )
    }

    const zai = await ZAI.create()

    // Формируем сообщения для контекста
    const messages = [
      { role: 'system' as const, content: SYSTEM_PROMPT },
      ...previousMessages.map((m: {role: string, content: string}) => ({
        role: m.role as 'user' | 'assistant',
        content: m.content
      })),
      { role: 'user' as const, content: question }
    ]

    const completion = await zai.chat.completions.create({
      messages,
      temperature: 0.7,
      max_tokens: 1000
    })

    const answer = completion.choices[0]?.message?.content || 'Извини, я не смог обработать твой вопрос. Попробуй задать его по-другому!'

    return NextResponse.json({ answer })
  } catch (error) {
    console.error('AI Teacher API error:', error)
    
    // Fallback ответ при ошибке API
    const fallbackAnswers: Record<string, string> = {
      'дроби': `📚 **Дроби — это части целого!**

Представь пиццу, разрезанную на кусочки. Каждый кусочек — это дробь!

🔹 **Числитель** (верхнее число) — сколько частей взяли
🔹 **Знаменатель** (нижнее число) — на сколько частей разделили

**Пример:** 🍕 Пиццу разрезали на 8 кусков. Ты съел 3 куска. Это дробь 3/8 (три восьмых).`,

      'уравнение': `📚 **Как решать уравнения:**

1️⃣ Найди неизвестное (обычно это x)
2️⃣ Перенеси числа в одну сторону
3️⃣ При переносе через = меняй знак
4️⃣ Вычисли ответ

**Пример:** x + 5 = 12
→ x = 12 - 5
→ x = 7 ✓`,

      'default': `Извини, у меня небольшие технические неполадки! 😅

Но я постараюсь помочь:
- 📚 Перефразируй свой вопрос
- 💡 Уточни, какой именно аспект тебя интересует
- 🎯 Или загляни в раздел обучения!

Попробуй ещё раз! 🌟`
    }

    const reqBody = await request.clone().json().catch(() => ({}))
    const question = reqBody?.question?.toLowerCase() || ''
    let answer = fallbackAnswers.default

    for (const [key, value] of Object.entries(fallbackAnswers)) {
      if (question.includes(key)) {
        answer = value
        break
      }
    }

    return NextResponse.json({ answer })
  }
}
